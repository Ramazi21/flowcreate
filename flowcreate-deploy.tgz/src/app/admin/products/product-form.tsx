"use client";

import { useState } from "react";

const initialForm = {
  title: "",
  slug: "",
  price: "",
  imageUrl: "",
  description: "",
  stock: "0",
  category: "",
};

export function ProductForm() {
  const [form, setForm] = useState(initialForm);
  const [status, setStatus] = useState<"idle" | "saving" | "success" | "error">("idle");
  const [message, setMessage] = useState("");

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("saving");
    setMessage("");

    const response = await fetch("/api/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...form,
        price: Number(form.price),
        stock: Number(form.stock),
      }),
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      setStatus("error");
      setMessage(typeof error.error === "string" ? error.error : "Не удалось создать товар");
      return;
    }

    setStatus("success");
    setMessage("Товар создан");
    setForm(initialForm);
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4 rounded border border-black/10 bg-white p-6">
      <div className="grid gap-4 md:grid-cols-2">
        <input
          required
          placeholder="Название"
          value={form.title}
          onChange={(event) => setForm((current) => ({ ...current, title: event.target.value }))}
          className="rounded border border-black/20 px-3 py-2"
        />
        <input
          required
          placeholder="Slug"
          value={form.slug}
          onChange={(event) => setForm((current) => ({ ...current, slug: event.target.value }))}
          className="rounded border border-black/20 px-3 py-2"
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <input
          required
          type="number"
          min={0}
          placeholder="Цена, ₽"
          value={form.price}
          onChange={(event) => setForm((current) => ({ ...current, price: event.target.value }))}
          className="rounded border border-black/20 px-3 py-2"
        />
        <input
          required
          type="number"
          min={0}
          placeholder="Остаток"
          value={form.stock}
          onChange={(event) => setForm((current) => ({ ...current, stock: event.target.value }))}
          className="rounded border border-black/20 px-3 py-2"
        />
      </div>

      <input
        required
        type="url"
        placeholder="URL изображения"
        value={form.imageUrl}
        onChange={(event) => setForm((current) => ({ ...current, imageUrl: event.target.value }))}
        className="w-full rounded border border-black/20 px-3 py-2"
      />
      <input
        required
        placeholder="Категория"
        value={form.category}
        onChange={(event) => setForm((current) => ({ ...current, category: event.target.value }))}
        className="w-full rounded border border-black/20 px-3 py-2"
      />
      <textarea
        required
        rows={4}
        placeholder="Описание"
        value={form.description}
        onChange={(event) => setForm((current) => ({ ...current, description: event.target.value }))}
        className="w-full rounded border border-black/20 px-3 py-2"
      />

      <button
        type="submit"
        disabled={status === "saving"}
        className="rounded bg-[#32495e] px-5 py-2 text-sm font-semibold text-white disabled:opacity-60"
      >
        {status === "saving" ? "Сохраняем..." : "Создать товар"}
      </button>
      {message ? <p className="text-sm text-charcoal/80">{message}</p> : null}
    </form>
  );
}
