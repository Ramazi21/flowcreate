import { redirect } from "next/navigation";
import { auth, signIn } from "@/auth";
import { Button } from "@/components/ui/button";

export default async function SignInPage({
  searchParams,
}: {
  searchParams?: Promise<{ callbackUrl?: string }>;
}) {
  const session = await auth();
  if (session?.user) redirect("/");

  const params = (await searchParams) ?? {};
  const callbackUrl = params.callbackUrl ?? "/";

  return (
    <div className="mx-auto flex min-h-[60vh] max-w-md flex-col items-center justify-center gap-6 px-4 py-14 text-center">
      <h1 className="text-3xl font-black">Вход в аккаунт</h1>
      <p className="text-sm text-charcoal/70">Используйте Google, чтобы авторизоваться и управлять товарами.</p>
      <form
        action={async () => {
          "use server";
          await signIn("google", { redirectTo: callbackUrl });
        }}
      >
        <Button type="submit">Войти через Google</Button>
      </form>
    </div>
  );
}
