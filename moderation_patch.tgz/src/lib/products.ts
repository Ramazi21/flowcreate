import { db } from "@/lib/db";
import { works } from "@/lib/mock-data";
import { ProductStatus } from "@prisma/client";

export type ProductView = {
  id: string;
  title: string;
  subtitle: string;
  price: string;
  imageUrl: string;
  slug: string;
  category: string;
  stock: number;
  status: ProductStatus;
};

function formatPrice(price: number) {
  return `${price.toLocaleString("ru-RU")} ₽`;
}

export async function listProducts(): Promise<ProductView[]> {
  try {
    const products = await db.product.findMany({
      where: { status: ProductStatus.APPROVED },
      orderBy: { createdAt: "desc" },
    });

    if (!products.length) return [];

    return products.map((item) => ({
      id: item.id,
      title: item.title,
      subtitle: item.description,
      price: formatPrice(item.price),
      imageUrl: item.imageUrl,
      slug: item.slug,
      category: item.category,
      stock: item.stock,
      status: item.status,
    }));
  } catch {
    return works.map((item) => ({
      id: item.id,
      title: item.name,
      subtitle: item.subtitle,
      price: item.price,
      imageUrl: item.imageUrl,
      slug: item.id,
      category: "decor",
      stock: 10,
      status: ProductStatus.APPROVED,
    }));
  }
}
